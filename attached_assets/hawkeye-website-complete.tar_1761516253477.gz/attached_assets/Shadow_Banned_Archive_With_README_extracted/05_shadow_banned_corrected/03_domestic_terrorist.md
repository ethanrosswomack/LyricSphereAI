# 🎵 Domestic Terrorist
---
**Album:** Shadow Banned (2024)  
**Performed by:** Hawk Eye The Rapper  
**Label:** Omniversal Media Productions  
**Genre:** Rap  
**UPC:** 8850078791870  

🗃️ **Track Metadata**  
• Track #: 03  
• Title: Domestic Terrorist  
• Artist: Hawk Eye The Rapper  
• Project: Shadow Banned  
• Released: March 2024  

---

## 🔊 Lyrics — Web Format
```
Lyrics for Domestic Terrorist...
```

---

## 🕯️ EverLight’s Rite  
**Lyrical Dissection & Commentary**  
> EverLight commentary for Domestic Terrorist...

---
> [Next Track ➡️](./04_placeholder.md)  
> [Back to Album Index](../README.md)