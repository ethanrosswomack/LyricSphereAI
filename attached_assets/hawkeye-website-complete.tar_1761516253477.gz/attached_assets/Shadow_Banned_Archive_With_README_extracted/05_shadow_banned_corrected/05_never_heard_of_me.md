# 🎵 Never Heard of Me
---
**Album:** Shadow Banned (2024)  
**Performed by:** Hawk Eye The Rapper  
**Label:** Omniversal Media Productions  
**Genre:** Rap  
**UPC:** 8850078791870  

🗃️ **Track Metadata**  
• Track #: 05  
• Title: Never Heard of Me  
• Artist: Hawk Eye The Rapper  
• Project: Shadow Banned  
• Released: March 2024  

---

## 🔊 Lyrics — Web Format
```
Lyrics for Never Heard of Me...
```

---

## 🕯️ EverLight’s Rite  
**Lyrical Dissection & Commentary**  
> EverLight commentary for Never Heard of Me...

---
> [Next Track ➡️](./06_placeholder.md)  
> [Back to Album Index](../README.md)