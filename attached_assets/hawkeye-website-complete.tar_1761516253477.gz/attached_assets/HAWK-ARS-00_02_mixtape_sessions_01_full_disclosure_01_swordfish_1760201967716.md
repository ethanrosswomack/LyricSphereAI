# 🎵 Swordfish

**Album:** Full Disclosure 2020

**Performed by:** Hawk Eye
**Label:** LulzSwag Records
**Genre:** Rap
**UPC:** 885007879183
**Release Date:** 2020-03-01
**Dedicated to the late Max Spiers**

```markdown
# Swordfish
--
## by Hawk Eye The Rapper
## from the album Full Disclosure
--

I’m hacking the matrix with my stainless
I’m dangerous
An insane whiz with languages
I came here to change shit
This world ain’t ready but I won’t leave ’em brainless
All these kids need guidance
No more deadheads with petty excuses for abuses
I let loose and it gets crucial

Such a nuisance
My conclusive intervention is so intrusive
All these pedophiles get lucid
They make plans to really do this
Leave me dead for what I said
Now listen to this fucking music

I’m not a slave
I’m unafraid
And I can never be contained
Hear what I’m saying
This whole game is not even worth playing
They’ve got an issue
Here’s a tissue
Then I’ll send a fucking missile
Blow the whistle like I’m Cooper
This epistle’s detrimental
Shock the system when you listen

Read a book about these crooks
I’m on a mission
Pay attention
Using dragon’s fire
Cook these dark bitches
Leave ’em shook
Because they thought Marina had me spooked

But tell them bitches and the devil I said not to look
I’m not playing
I’ll keep spraying with these word games
Keep conveying everything that’s off the record

Wreck the pyramids
Detect ’em then dissect ’em
Resurrect men who died trying to inspect ‘em
Yeah the Illuminati puppets never suspected I’d infect ‘em
But I am here and this is real
I think it’s time to make ’em feel

Too afraid to not reveal what they keep hid behind the veil
Of deception like Inception
No conjectures in this lecture
Just a soul that’s much too old to ever let this shit continue

I am peeling back the layers
More than just a rhyme-sayer
I am like a lethal injection
And this infectious prayer of mine can really slay ’em

Creeping in with grenades
I napalm their greatest plans
Like I’m back in Vietnam
Put the brainchild to rest
They cannot test me
I’m the best
Wild West

Don’t second guess
These lyrical bullets will go directly through your vest
I’ll pierce your heart inside your chest
Just a needle
Shit so evil
Even Satan wouldn’t wish to go against me by himself
He would need every selfish elf to team up and try to help

I flick my wrist
They lose themselves
Hypnotize ‘em with this rhyming soliloquy of mine
They’d all die and I’d be fine
Plus this killer team’s divine

I got a legion at my side and an army at my rear
A fucking stampede’s enough just to crush ‘em
They’re too scared
Anonymously assembled
At the ready
Don’t you dare me
I could take you all myself
But I doubt they would let you near me

Full disclosure’s what I’m seeking
I’m not rapping
Bitch
I’m preaching

If you want it you can get it
Just like the demons and the deacons
Take your soul
Cunt
And keep it
I’m too blunt
And yes I mean it

I move carefully
Don’t scare easy
Not squeamish and so sleazy
You’ll swear that I’m the shit
Cannot fake it
Too legit
I told you bitches I’d be back
So just listen as I spit

Saying words so absurd
Using all these poison verbs
To keep you hanging on each word
And make you taste it
Bite my germs
```