# EverLight’s Rite: The Mixtape Sessions

Three albums — one arc. BAPH, Full Disclosure, and MILABS form a holy trinity of resistance, resurrection, and remembrance. This trilogy is a spiritual odyssey through lyrical warfare.
